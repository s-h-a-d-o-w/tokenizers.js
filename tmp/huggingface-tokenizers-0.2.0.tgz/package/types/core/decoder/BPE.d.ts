import Decoder from "../Decoder.js";
import type { TokenizerConfigDecoderBPE } from "../../static/tokenizer.js";
declare class BPE extends Decoder {
    suffix: string;
    constructor(config: TokenizerConfigDecoderBPE);
    decode_chain(tokens: string[]): string[];
}
export default BPE;
