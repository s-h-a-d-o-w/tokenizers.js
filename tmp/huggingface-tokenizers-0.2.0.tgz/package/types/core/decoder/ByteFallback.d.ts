import Decoder from "../Decoder.js";
import type { TokenizerConfigDecoderByteFallback } from "../../static/tokenizer.js";
declare class ByteFallback extends Decoder {
    text_decoder: TextDecoder;
    constructor(config: TokenizerConfigDecoderByteFallback);
    decode_chain(tokens: string[]): string[];
}
export default ByteFallback;
