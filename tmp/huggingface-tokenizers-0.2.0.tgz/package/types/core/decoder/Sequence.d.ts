import Decoder from "../Decoder.js";
import { TokenizerConfigDecoderSequence } from "../../static/tokenizer.js";
/**
 * Apply a sequence of decoders.
 */
declare class Sequence extends Decoder {
    decoders: Decoder[];
    /**
     * Creates a new instance of DecoderSequence.
     * @param config The configuration object.
     */
    constructor(config: TokenizerConfigDecoderSequence);
    decode_chain(tokens: string[]): string[];
}
export default Sequence;
