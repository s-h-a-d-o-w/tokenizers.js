import Decoder from "../Decoder.js";
import { TokenizerConfigDecoderReplace } from "../../static/tokenizer.js";
declare class Replace extends Decoder {
    config: TokenizerConfigDecoderReplace;
    pattern: RegExp | null;
    /**
     * @param config The configuration object for the decoder.
     */
    constructor(config: TokenizerConfigDecoderReplace);
    decode_chain(tokens: string[]): string[];
}
export default Replace;
