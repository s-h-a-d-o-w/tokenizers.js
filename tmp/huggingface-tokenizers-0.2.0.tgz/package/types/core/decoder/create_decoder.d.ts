import type Decoder from "../Decoder.js";
import type { TokenizerConfigDecoder } from "../../static/tokenizer.js";
declare function create_decoder(config: TokenizerConfigDecoder): Decoder | null;
export default create_decoder;
