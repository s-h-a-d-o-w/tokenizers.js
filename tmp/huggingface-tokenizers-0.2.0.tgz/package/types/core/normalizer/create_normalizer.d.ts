import type { TokenizerConfigNormalizer } from "../../static/tokenizer.js";
import type Normalizer from "../Normalizer.js";
declare function create_normalizer(config: TokenizerConfigNormalizer): Normalizer | null;
export default create_normalizer;
