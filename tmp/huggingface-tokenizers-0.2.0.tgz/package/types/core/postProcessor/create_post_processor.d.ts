import type PostProcessor from "../PostProcessor.js";
import type { TokenizerConfigPostProcessor } from "../../static/tokenizer.js";
declare function create_post_processor(config: TokenizerConfigPostProcessor): PostProcessor | null;
export default create_post_processor;
