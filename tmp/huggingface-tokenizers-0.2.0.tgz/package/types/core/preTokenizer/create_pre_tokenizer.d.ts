import type PreTokenizer from "../PreTokenizer.js";
import type { TokenizerConfigPreTokenizer } from "../../static/tokenizer.js";
declare function create_pre_tokenizer(config: TokenizerConfigPreTokenizer): PreTokenizer | null;
export default create_pre_tokenizer;
