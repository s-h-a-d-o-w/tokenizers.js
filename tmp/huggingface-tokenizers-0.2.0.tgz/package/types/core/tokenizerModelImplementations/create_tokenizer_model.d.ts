import type TokenizerModel from "../TokenizerModel.js";
import type { TokenizerModelConfig, TokenizerConfig } from "../../static/tokenizer.js";
declare function create_tokenizer_model(model_config: TokenizerModelConfig, config: TokenizerConfig): TokenizerModel;
export default create_tokenizer_model;
